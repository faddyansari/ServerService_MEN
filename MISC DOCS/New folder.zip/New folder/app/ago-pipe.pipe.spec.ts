import { AgoPipePipe } from './ago-pipe.pipe';

describe('AgoPipePipe', () => {
  it('create an instance', () => {
    const pipe = new AgoPipePipe();
    expect(pipe).toBeTruthy();
  });
});
