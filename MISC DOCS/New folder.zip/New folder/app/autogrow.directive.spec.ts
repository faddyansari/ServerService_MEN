import { AutogrowDirective } from './autogrow.directive';

describe('AutogrowDirective', () => {
  it('should create an instance', () => {
    const directive = new AutogrowDirective();
    expect(directive).toBeTruthy();
  });
});
