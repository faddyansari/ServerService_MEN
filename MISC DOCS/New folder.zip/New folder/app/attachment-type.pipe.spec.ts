import { AttachmentTypePipe } from './attachment-type.pipe';

describe('AttachmentTypePipe', () => {
  it('create an instance', () => {
    const pipe = new AttachmentTypePipe();
    expect(pipe).toBeTruthy();
  });
});
