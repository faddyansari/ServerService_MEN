import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-contact-dialog',
  templateUrl: './update-contact-dialog.component.html',
  styleUrls: ['./update-contact-dialog.component.scss']
})
export class UpdateContactDialogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
