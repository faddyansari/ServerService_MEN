import { MonthPipePipe } from './month-pipe.pipe';

describe('MonthPipePipe', () => {
  it('create an instance', () => {
    const pipe = new MonthPipePipe();
    expect(pipe).toBeTruthy();
  });
});
