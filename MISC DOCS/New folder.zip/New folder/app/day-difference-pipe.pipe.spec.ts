import { DayDifferencePipePipe } from './day-difference-pipe.pipe';

describe('DayDifferencePipePipe', () => {
  it('create an instance', () => {
    const pipe = new DayDifferencePipePipe();
    expect(pipe).toBeTruthy();
  });
});
