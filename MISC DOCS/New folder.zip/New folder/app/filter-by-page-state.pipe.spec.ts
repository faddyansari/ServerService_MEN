import { FilterByPageStatePipe } from './filter-by-page-state.pipe';

describe('FilterByPageStatePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterByPageStatePipe();
    expect(pipe).toBeTruthy();
  });
});
