// import { NgModule } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { Routes, RouterModule } from '@angular/router';
// import { SharedModule } from '../shared/shared.module';
// import { NgxSummernoteModule } from 'ngx-summernote';
// // import { CompaignMgtComponent } from '../../pages/settings/bulk-marketing-email/compaign-mgt/compaign-mgt.component';
// import { TemplateBuilderComponent } from '../../pages/settings/bulk-marketing-email/template-builder/template-builder.component';
// import { ImportTemplateComponent } from '../../pages/settings/bulk-marketing-email/import-template/import-template.component';
// import { HtmlEditorComponent } from '../../pages/settings/bulk-marketing-email/html-editor/html-editor.component';
// import { BulkMarketingEmailComponent } from '../../pages/settings/bulk-marketing-email/bulk-marketing-email.component';
// import { ColorPickerModule } from 'ngx-color-picker';
// import { EmailTemplateService } from '../../../services/LocalServices/EmailTemplateService';
// import { LayoutComponent } from '../../pages/settings/bulk-marketing-email/template-builder/layout/layout.component';
// import { EmailTemplateListComponent } from '../../pages/settings/bulk-marketing-email/email-template-list/email-template-list.component';
// // import { ConfirmationGuard } from '../../../services/ConfirmationGuard';
// // const routes: Routes = [
// //     {
// //         path: '', component: BulkMarketingEmailComponent,

// //         children: [
// //             { path: 'templateBuilder', component: TemplateBuilderComponent},//, canDeactivate : [ConfirmationGuard] },
// //             { path: 'importTemplate', component: ImportTemplateComponent},//, canDeactivate : [ConfirmationGuard] },
// //             { path: 'htmlEditor', component: HtmlEditorComponent}//, canDeactivate : [ConfirmationGuard] }
// //         ],
// //     }
// // ];


// const routes: Routes = [
//     { path: '', component: BulkMarketingEmailComponent },
//     { path: 'templateBuilder', component: TemplateBuilderComponent },
//     { path: 'importTemplate', component: ImportTemplateComponent },
//     { path: 'htmlEditor', component: HtmlEditorComponent },
  
//     // {path:'', children:[
//     //     // {path: '', redirectTo:'agentfeedback'},
//     //     {path:'templateBuilder', component: TemplateBuilderComponent},
//     //     {path:'importTemplate', component: ImportTemplateComponent},
//     //     { path: 'htmlEditor', component: HtmlEditorComponent }
//     // ], component: BulkMarketingEmailComponent}
// ];

// @NgModule({
//     imports: [
//         CommonModule,
//         SharedModule,
//         NgxSummernoteModule,
//         RouterModule.forChild(routes),
//         ColorPickerModule
//     ],
//     exports: [RouterModule],
//     providers:[
//         EmailTemplateService,
//         // ConfirmationGuard
//     ],
//     declarations: [
//         TemplateBuilderComponent,
//         ImportTemplateComponent,
//         HtmlEditorComponent,
//         LayoutComponent,
//         EmailTemplateListComponent,
//         BulkMarketingEmailComponent

//     ]
// })
// export class BulkMarketingEmailModule { }