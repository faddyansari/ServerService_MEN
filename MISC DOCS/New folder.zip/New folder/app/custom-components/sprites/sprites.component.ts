import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-sprites',
  templateUrl: './sprites.component.html',
  styleUrls: ['./sprites.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class SpritesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
