import { ColorPhrasePipe } from './color-phrase.pipe';

describe('ColorPhrasePipe', () => {
  it('create an instance', () => {
    const pipe = new ColorPhrasePipe();
    expect(pipe).toBeTruthy();
  });
});
