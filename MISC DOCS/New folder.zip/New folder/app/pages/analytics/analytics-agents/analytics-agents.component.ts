import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
	selector: 'app-analytics-agents',
	templateUrl: './analytics-agents.component.html',
	styleUrls: ['./analytics-agents.component.css'],
	encapsulation: ViewEncapsulation.None
})
export class AnalyticsAgentComponent implements OnInit {

	constructor() {
	}

	ngOnInit() {
		
	}
	ngAfterViewInit() {

	}

}
