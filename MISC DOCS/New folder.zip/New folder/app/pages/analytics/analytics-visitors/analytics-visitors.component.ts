import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
	selector: 'app-analytics-visitors',
	templateUrl: './analytics-visitors.component.html',
	styleUrls: ['./analytics-visitors.component.scss'],
	encapsulation: ViewEncapsulation.None
})
export class AnalyticsVisitorsComponent implements OnInit {
	constructor() {
	}
	ngOnInit() {
	}
	ngAfterViewInit() {		
	}
}
