import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
	selector: 'app-analytics-chats',
	templateUrl: './analytics-chats.component.html',
	styleUrls: ['./analytics-chats.component.css'],
	encapsulation: ViewEncapsulation.None
})
export class AnalyticsChatsComponent implements OnInit {
	
	constructor() {
	}

	ngOnInit() {

	}
	ngAfterViewInit() {

	}
}
