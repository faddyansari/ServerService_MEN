import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-analytics-chatcustomdashboard',
  templateUrl: './analytics-chatcustomdashboard.component.html',
  styleUrls: ['./analytics-chatcustomdashboard.component.css']
})
export class AnalyticsChatcustomdashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  onFilterResult(event){
    
  }

}
