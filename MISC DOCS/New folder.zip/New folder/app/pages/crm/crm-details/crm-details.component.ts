import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-crm-details',
  templateUrl: './crm-details.component.html',
  styleUrls: ['./crm-details.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class CrmDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
