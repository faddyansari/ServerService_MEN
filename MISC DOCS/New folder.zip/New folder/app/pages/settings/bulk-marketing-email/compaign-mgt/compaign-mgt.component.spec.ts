// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { CompaignMgtComponent } from './compaign-mgt.component';

// describe('CompaignMgtComponent', () => {
//   let component: CompaignMgtComponent;
//   let fixture: ComponentFixture<CompaignMgtComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ CompaignMgtComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(CompaignMgtComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
