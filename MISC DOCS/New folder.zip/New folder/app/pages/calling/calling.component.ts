import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
	selector: 'app-calling',
	templateUrl: './calling.component.html',
	styleUrls: ['./calling.component.scss'],
	encapsulation: ViewEncapsulation.None,
})
export class CallingComponent implements OnInit {

	constructor() {

	}

	ngOnInit() {
	}

}
