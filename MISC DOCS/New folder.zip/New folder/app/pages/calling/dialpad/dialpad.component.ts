import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-dialpad',
  templateUrl: './dialpad.component.html',
  styleUrls: ['./dialpad.component.scss'],
	encapsulation: ViewEncapsulation.None,
})
export class DialpadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
