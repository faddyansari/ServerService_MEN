import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PagesCoreComponent } from './pages-core/pages-core.component';


import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ForcedDirectedGraphComponent } from './components/comp/forcedDirected/forcedDirected.component';
import { PieChartComponent } from './components/comp/pieChart/pieChart.component';
import { LineChartComponent } from './components/comp/line-chart/line-chart.component';
import { MapChartComponent } from './components/comp/map-chart/map-chart.component';
import { BarChartComponent } from './components/comp/bar-chart/bar-chart.component';

import { AuthGuard } from '../auth/guards/authGuard';
import { RaceChartComponent } from './components/comp/race-chart/race-chart.component';


const routes: Routes = [
  {
    path: '',
    component: PagesCoreComponent,
    children: [
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'dashboard'
      },
      {
        path: 'dashboard', canActivate: [AuthGuard],
        component: DashboardComponent,
      },
      {
        path: 'forcedDirected', canActivate: [AuthGuard],
        component: ForcedDirectedGraphComponent,
      },
      {
        path: 'pieChart', canActivate: [AuthGuard],
        component: PieChartComponent,
      },
      {
        path: 'lineChart', canActivate: [AuthGuard],
        component: LineChartComponent,
      },
      {
        path: 'mapChart', canActivate: [AuthGuard],
        component: MapChartComponent,
      },
      {
        path: 'barChart', canActivate: [AuthGuard],
        component: BarChartComponent,
      },
      {
        path: 'raceChart', canActivate: [AuthGuard],
        component: RaceChartComponent,
      },
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PagesRoutingModule { }
