import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PagesRoutingModule } from './pages-routing.module';
import { SharedModule } from '../shared/shared.module';
import { PagesCoreComponent } from './pages-core/pages-core.component';
import { LeftPanelComponent } from './common/left-panel/left-panel.component';
import { RightPanelComponent } from './common/right-panel/right-panel.component';
import { HeaderComponent } from './common/header/header.component';
import { ContentSectionComponent } from './content-section/content-section.component';

import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ForcedDirectedGraphComponent } from './components/comp/forcedDirected/forcedDirected.component';
import { PieChartComponent } from './components/comp/pieChart/pieChart.component';
import { LineChartComponent } from './components/comp/line-chart/line-chart.component';
import { MapChartComponent } from './components/comp/map-chart/map-chart.component';
import { BarChartComponent } from './components/comp/bar-chart/bar-chart.component';
import { RaceChartComponent } from './components/comp/race-chart/race-chart.component';



@NgModule({
  declarations: [
    PagesCoreComponent,
    LeftPanelComponent,
    RightPanelComponent,
    HeaderComponent,
    ContentSectionComponent,
    DashboardComponent,
    ForcedDirectedGraphComponent,
    PieChartComponent,
    LineChartComponent,
    MapChartComponent,
    BarChartComponent,
    RaceChartComponent,
  ],
  imports: [
    CommonModule,
    PagesRoutingModule,
    SharedModule
  ],
})
export class PagesModule { }
