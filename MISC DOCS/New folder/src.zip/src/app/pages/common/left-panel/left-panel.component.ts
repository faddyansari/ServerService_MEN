import { Component, OnInit, Input, HostListener } from '@angular/core';
import { LayoutService } from '../../../shared/services/layout.service';

@Component({
  selector: 'app-left-panel',
  templateUrl: './left-panel.component.html',
  styleUrls: ['./left-panel.component.scss']
})
export class LeftPanelComponent implements OnInit {
  asidebarHeight: number;
  @Input() navLayout: string;
  @Input() defaultNavbar: string;
  @Input() toggleNavbar: string;
  @Input() toggleStatus: boolean;
  @Input() navbarEffect: string;
  @Input() deviceType: string;
  @Input() headerColorTheme: string;
  @Input() navbarColorTheme: string;
  @Input() activeNavColorTheme: string;
  title: any;
  menuList: any;
  selected: any;
  constructor(private layoutService: LayoutService) { }

  isActive(item) {
      return this.selected === item;
  }
  onItemSelect(item) {
    this.selected = (this.selected === item ? item : item);
      }
  onSubItemSelect(event,item) {
    event.stopPropagation();
    this.selected = (this.selected === item ? item : item);
    
  }


  @HostListener('window:resize', ['$event'])
  onResizeHeight(event: any) {
      this.asidebarHeight = window.innerHeight;
  }



  ngOnInit() {
    this.layoutService.setAsidebarHeightCast.subscribe(setSidebarHeight => this.asidebarHeight = setSidebarHeight);

    this.title = 'Navigation';
    this.menuList = [
      {
        name: 'Dashboard',
        icon: 'fas fa-tachometer-alt',
        url: '/dashboard',
        badge: 'New',
        badgeBg: 'bg-danger',
      },
      {
        name: 'AM4-CHARTS',
        icon: 'far fa-circle',
        subMenu: [
          {
            name: 'Network graph',
            icon: 'far fa-circle',
            url: '/forcedDirected',
          },
          {
            name: 'Pie Chart',
            icon: 'far fa-circle',
            url: '/pieChart',
          },
          {
            name: 'Line Chart',
            icon: 'far fa-circle',
            url: '/lineChart',
          },
          {
            name: 'Map Chart',
            icon: 'far fa-circle',
            url: '/mapChart',
          },
          {
            name: 'Bar Chart',
            icon: 'far fa-circle',
            url: '/barChart',
          },
          {
            name: 'Race Chart',
            icon: 'far fa-circle',
            url: '/raceChart',
          }
        ]
      },

    ];
  }

}
