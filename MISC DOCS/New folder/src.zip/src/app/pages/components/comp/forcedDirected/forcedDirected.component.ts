import { Component, OnInit } from '@angular/core';
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import * as am4plugins_forceDirected from "@amcharts/amcharts4/plugins/forceDirected";
import * as am4plugins_bullets from "@amcharts/amcharts4/plugins/bullets";

@Component({
  selector: 'app-forcedDirected',
  templateUrl: './forcedDirected.component.html',
  styleUrls: ['./forcedDirected.component.scss']
})
export class ForcedDirectedGraphComponent implements OnInit {

  private chart: any;
  plottingData = [];
  data = [
    { name: "Zulfiqar Ali Bhutto", relation: "Father In Law" },
    { name: "Azra Fazal Pechuho", relation: "Brother" },
    { name: "Azra Fazal Pechuho", relation: "Sister" },
    { name: "Abdul Razzak Yaqub", relation: "Associate" },
    { name: "Ara Zardari", relation: "Mother" },
    { name: "Aseefa Bhutto Zardari", relation: "Daughter" },
    { name: "Aslam Hayat Qureshi", relation: "Associate" },
    { name: "Awais Muzaffar", relation: "Half Brother" },
    { name: "Bakhtawar Bhutto Zardari", relation: "Daughter" },
    { name: "Benazir Bhutto", relation: "Spouse" },
    { name: "Bilawal Bhutto Zardari", relation: "Son" },
    { name: "Bilquis Sultana Zardari", relation: "Mother" },
    { name: "Fazalullah Pechuho", relation: "Brother In Law" },
    { name: "Faryal Talpur", relation: "Sister" },
    { name: "Hakim Ali Zardari", relation: "Father" },
    { name: "Munawar Talpur", relation: "Brother In Law" },
    { name: "Murtaza Bhutto", relation: "Brother in Law" },
    { name: "Owais Muzaffar", relation: "Half Brother" },
    { name: "Sanam Bhutto", relation: "Sister in Law" },
    { name: "Shahnawaz Bhutto", relation: "Brother in Law" }
  ];
  constructor() { }

  ngOnInit() {

    //Transfrom data into am4chart manner

    // this.plottingData = this.TransformData(this.data);
    // if (this.plottingData) {

    // Theme applied
    am4core.useTheme(am4themes_animated);

    // Create chart
    let chart = am4core.create(
      "chartdiv",
      am4plugins_forceDirected.ForceDirectedTree
    );

    this.chart = chart;

    //hide logo of am4charts
    chart.logo.height = -1500;
    chart.zoomable = true;
    chart.paddingRight = am4core.percent(10);
    chart.legend = new am4charts.Legend();
    // For zoomout key
    chart.zoomOutButton.background.cornerRadius(5, 5, 5, 5);
    chart.zoomOutButton.background.fill = am4core.color("#25283D");
    chart.zoomOutButton.icon.stroke = am4core.color("#EFD9CE");
    chart.zoomOutButton.icon.strokeWidth = 2;
    chart.zoomOutButton.background.states.getKey(
      "hover"
    ).properties.fill = am4core.color("#606271");
    // Create series
    var series = chart.series.push(
      new am4plugins_forceDirected.ForceDirectedSeries()
    );

    // Set data
    // series.data = this.plottingData;
    series.data = [
      {
        name: "Zardari",
        width: 50,
        height: 50,
        path:
          "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAKAAeAMBIgACEQEDEQH/xAAcAAAABwEBAAAAAAAAAAAAAAAAAQIDBAUGBwj/xABEEAABAwIDBQQFCQUHBQAAAAABAAIDBBEFEiEGMUFRYRMicbEjMoGRoQcUJFJicnOywRUlQtHhNWOCkqLw8RYzNENT/8QAGAEAAwEBAAAAAAAAAAAAAAAAAAECAwT/xAAgEQACAgIDAQADAAAAAAAAAAAAAQIDETESITJBBCIj/9oADAMBAAIRAxEAPwDYbOvvjVX+F+quMQk3Dos7s1JfGKr8I+at6+T0gHRc8X+p0S2UcrvTnxSZJO8kyn0pPVR5pLOQhsuaKTuKYXqnope4pktTFDC+aaRscbGlz3vNg0DiSqIK/HD9Fd4p/YH/AM2t6wt/MsBtT8oNPJmpsGhE4B71RKCGf4RvPibKq2f+UDF8IqpahrIZc7Q10bou6Re/Ag/FJQfLJTmuOD0O890+CyNee8/x/VZag+WelecmKYVLG0ixkpnh1j911tParqnxahxmldVYdO2WMnUbnMPJw4FVPRENmfwg/v2D7xW5xz+zp/wisJhB/fsH3it3jWuHVH4R8lzV6Z0z2jN7KkftVn3H+S6BEB2YOt9y55ssf3tF1a/8pXQov+0rp0TdsfaO7e6CMaRhBbGGzCbKSXxep1/9J8wrWtk+lAXVDsc6+LVH4DvMKwr5rYoxl94WcfBrP0R5jaRyr6qSzlNnddzrKorXkEoQifBWR09O+ad4ZHG0uc4nQADUrn+0G0WIbX1n7PwxrmUDT6h0LrfxSHyb5pG2+LSGCLC6d2r+/MGnhwB8/YFpNl8Miw/C4I2gZ3DPK76xKuT4rIQhzeCloNiWNaPnkz3O5s09is49kqQRiwdobrS54w3LkB620RRysBIy214LBzkdka4JaMfiWyVJK0mBxjcs9Ty4xsnVZ4Hhsb9C0jMx46hdIqJGEnulVOIUUdbA+KRoLXixVRm/pNlKfaG9kq9uI4hR1AGVxcQ9v1XcV0rGNcNn/CPkuNfJyH0+0LqaV2rZHN9ouF2fFRfD5/wneSaiotnO5NpZMlsuf3xT9Q/8hXRmj0QXNdmnWxemPV35XLpDHd1vgEqdMd3pEr+AIJBd3QgtjE5zsTritR+AfzBP4m+2OMHRR9htcSqzypz+ZqXiv9vD7iyXg2l7FuN7qnrzvVoPVKrq1tyU0SzmNTEZdqpI5HG7qjLdw8LfBdEnqXxQvipTG2RkeYGoD2ssLDeGnXXcolXgscrGYk1sfbxTs7rWWLmEAa/WN/8AeiQ+mqaySaFrjlIyut70OSbNYQcUxulxrFmzAvfQvgdwjEnwJaFpqCqjq4yXRjunLm69RvCzzMIjhd3YIgAC0vzOLiLe0hWGHs7CmmDHvDS24B331uf+UpcWaQU0IxDGGRPcyKDtXA2yscNPEqLRV01a+Ts6WQBjS5wL2OsBx7pKhNo21PzjtGmR7n94MldGQeYtzTZw6Sjre23sy27OR2Yi4I325FUlHBMnZkrcNqxhm3MLywkOnIcBvIcN4XbcScDQy66GI+S5LhOFsO18VbLnt2t2DKMpIaAfifgup4jJelf1jPkhtGLTT7Mhs8/LilMTzP5SujtkHZNPQLl2DSZa6B1+J8iugRz2iZrwUU6ZVu0XDZAWnwRKDHP3XG+4ILYxMjsGL1dc7lCB73f0R4kL47/g/VHsCPSYifsRj4uSq5t8ccfsDzWa8GkvYYZ3FBqo9DorfJaNQqll7qkiGysvamLCDe+nK29Jw2Rscr3PF7ap6VpbTylttBcm19P0UKnDLlrz6OVhYehWUlhnVXLMSVUVLp3uyjLGBfTe7+iRSV9NBTSsqaCojJIy5TnDvAgJl9DM2op3y1bIqI3zubBme3dYeG/WytTheCvja+bE5O0Y0hpMNvDc3VX0DlIztLXCCVzow7V3fY+2u7h0upmJ1ML2tayNrCeDeKg1lO/9rtjoZ/nUBFzI5vZuYeIHPThopVT2MDAHEOeGXAtuudAhpDUn9AycftLD2t4EF3xWvxOe0RHNqwUEjTilKWXuHNDvFa3GJcrT91QvpFm0Zmgflnj6fyW4bNeKEfZHkFz6lfZ414fotnBISaccDGCnV9Ju+Fq6bJBKeTCgq6tny08wvuagrk8EQjkTsAPR4i7heMfmT07L4tIegSdgB9Ar3f3zR/pP80843xSTwCI+EKXtj72gNsoFQzerR7SWXAJ6qjxXFsNoQfndfTQm3qmQF3uGqpENgjjBuDuO8c1l6smlrZqcPDmskAv7iP6pFft5QxQuGGRSTTHRr5W5GDrbefDRTdlKB20mx75439piVLVS9p/eh5z2PXXT2hN1tjhbxZPpZ2zMFzu3gc05Oy7r2IWbc+ppXkwEte3QseLbuBCaON4g549Gy4+0fKyySZ180W9Y9kBMtzmAtv1VZQRyYhUkG5jYc0ruA6JnJWYhPGx93yvOVkbBvKdq8Qh2Vx92GVD3OhlpInTOaL9nLdx0HKxAVKLZnOxIbpXfT4DuvIPNavH3Wb7FisPrKeevpxDPG45xoDrv5La7RNtCCeQWcU0mEmm0ZWE973+RW1jHdgfyZZYenN3gc7+RW9y3oYnD6oVU/RXfCuxCbuTX4tCCh4g+9O4+A+KCLH2FWiLgu3+FYFhlVCIaisqpJs7WxgMZbKBq49b7gVmsQ27xapqXzUvZUefhGMxHtcP0WTF+KNdCgksHJKbbyTq3GMSr3E1tfVTdHzOI/wAt7fBQWNBNgAB0QRhxb4KycjmVbX5JsaGGbS/MpT9HxFvZG507Uep79W+0LFA5hfclQSvp6iOeMkPieJGkc2m4+IQI9H43sxSYuO3jIhq//pa4f0cOPjv8VlGbKzPrPmpp42SA2LzIMo9o3+G9SNoNp8SrMDe7Aoy2JlL21ZXOfkyAMzOZEN5db+LcOB4jCunyRMmhqMwa3O9r/W53B3g9VpH8aNvehP8AJlV1s6pQbP0uDRmRjxLUkW7Vwt7hwC4HtXWuxHaXEqrNma6oc2Ox/gacrfgAulQbVVNVs3ikFeJ4a+lpDJG6RpD5IXCzX+Ivr7DzXJLWAFrKHFR6Q+Tl2xpzb2I3g3BVrTbRYvDEIfnsssI3MmOew6E6hVxtpfmjAPEW6KcDTaL6i2gDHtNRASNbmM9ORXScI2hwjF6SGGmrGNqQ2zoJe46/QHf7LrjFkD/VSoJaLdkns6vi4McDgQR3gguc020WJU8XYSTmogGuSY3I8HbwgsbK5N5RtXbFLsryMpF+OiJO2zNsUjeOvELpRyhI2AEm6ARajUIAdRO01RjdoiITA6Bs3izf+nJaXOBLNQyw5DrmfYxt08Mh96iNpoZccwnDXyB8ZlAlJAFwNcvttayodmj9OLW3zBl2jrcKdtC/sKunZTus+NwldIODgbj4rsqjityOW2X9EjV7X1HZ4HjtYLZ53xUMZ+ze7vgHLlTtLkrZbX4kKvZjBQ31quaarkA4OBy297nLP7P4hBhWMU9dVUoq44czuwcRZxLSBe4IIBINuNlyS2dKKspTTdO1JidMXQx5GWFhe/6BNsHHmpGAoFGUR0QBHlNg4+xGkzD0Yvx1QQBNB0uNyQ1wMzm8CL+1O2G/io+rKlt+KAHSLOQSnC6SmAG6acEpFZK3hAEzBJjBitOW73O7P/NoPiQrjaiMNdDDGLvOr3X6rNtc5j2vZ67CHN8RqPitdjVpKGN8PekmHaOdyBAN12UPMJI5rliSZj3zySxxxOeTHDmbG07mguJNvEpCJgsxvglFcj7Z0JYQk6296WiYOKMpDCKbk3Bp0zH3BOaqPMS+UNbqkwETuDz3dyCVNo2wsgkBNBBG9R5gfnER4XTuaw1bpzCalIL43h2gcmBJ4IrIDclJgJRN32SiknnyQAfFaAVbW7LXBzSkGLf6ovbyWfGqfZVBlJJTn1nDMPL9VtVPjkzsjnBEG5C2qGngjYLjNuzeSxNAx1QuEeltyI2QARJso0AzzvJJ7vLin5DZqYpTla51rlyGAKnogimJfuFvFBSBKd3BcXso7yxzS4GxFtE89zho1ua/ElRJue48UwJzDolg3TMR0CdaUwFFJIRoFAhI0NuCbdrM23FpHxCcPNJFiSeQQMQ/vEM+t5J5MwjM90h8B4J5CAIlIJRvTTigBM77MKOnb6JMTngpUYaIm6jckAzPZrSjSZwXHQXtwQSA/9k=",
        value: 150,
        children: [
          {
            name: "Daughters",
            value: -20,
            children: [
              {
                name: "Asifa",
                path:
                  "https://s3-us-west-2.amazonaws.com/s.cdpn.io/t-160/icon_cloud.svg",
                value: 50
              },
              {
                name: "Bakhtawar",
                path:
                  "https://s3-us-west-2.amazonaws.com/s.cdpn.io/t-160/icon_cloud.svg",
                value: 50
              }
            ]
          }
        ]
      }
    ];

    // Set up data fields
    series.dataFields.value = "value";
    series.dataFields.name = "name";
    series.dataFields.children = "children";
    series.dataFields.id = "name";
    series.dataFields.linkWith = "linkWith";
    series.manyBodyStrength = -50;
    series.fontSize = 10;
    series.minRadius = 15;
    series.maxRadius = 40;
    series.centerStrength = 0.5;

    series.links.template.distance = 1;
    series.links.template.strength = 1;
    series.dataFields.fixed = "true";

    // Label  properties
    series.nodes.template.label.text = "{name}";
    series.nodes.template.label.valign = "bottom";
    series.nodes.template.label.dy = 10;
    series.nodes.template.label.fill = am4core.color("#000");
    series.nodes.template.label.fontSize = 11;
    series.nodes.template.tooltipText = "{name}";

    // Lighten node colors
    // series.nodes.template.adapter.add("fill", (fill, target) => {
    //   return fill.lighten(target.dataItem.level * 0.25);
    // });

    // Image properties
    var icon = series.nodes.template.createChild(am4plugins_bullets.PinBullet);
    icon.image = new am4core.Image();
    icon.tooltipText = "{name}";
    icon.background.fill = chart.colors.getIndex(10);
    icon.background.fillOpacity = 0.9;
    icon.background.pointerAngle = 200;
    icon.background.pointerBaseWidth = 40;

    icon.image.propertyFields.href = "path";
    icon.circle.radius = am4core.percent(100);
    icon.circle.strokeWidth = 0;
    icon.background.pointerLength = 0;
    icon.background.disabled = true;



    // Link properties
    let linkTemplate = series.links.template;
    let linkHoverState = linkTemplate.states.create("hover");
    linkHoverState.properties.strokeOpacity = 10;
    linkHoverState.properties.strokeWidth = 10;


    // }
  }

  TransformData(data) {
    let children = [];
    children = data.reduce((o, cur) => {
      let occurs = o.reduce((n, item, i) => {
        return item.name === cur.relation ? i : n;
      }, -1);
      //If value founded
      if (occurs >= 0) {
        let i = { name: cur.name, value: 50 };
        o[occurs] = {
          name: cur.relation,
          children: o[occurs].children.concat(i),
          value: -50
        };
      }
      //If value not founded
      else {
        let temp = [cur];
        let f = {};
        let children = [];
        temp.map(res => {
          children.push({ name: res.name, value: 50 });
        });
        var obj = {
          name: cur.relation,
          value: -50,
          children: children
        };
        o = o.concat([obj]);
      }
      return o;
    }, []);
    // let person = this.getPersonByPep(1);
    let person = {
      name: "Asif Ali Zardari",
      path: "https://s3-us-west-2.amazonaws.com/s.cdpn.io/t-160/icon_cloud.svg"
    };
    return [
      { name: person.name, value: 150, path: person.path, children: children }
    ];
  }

  ngOnDestroy() {
    // Clean up chart when the component is removed
    if (this.chart) {
      this.chart.dispose();
    }
  }
}
