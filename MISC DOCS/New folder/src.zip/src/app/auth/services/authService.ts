import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { BehaviorSubject, Observable, throwError } from 'rxjs';
// import { map, catchError } from 'rxjs/operators';
import * as CryptoJS from "crypto-js";
import * as Base64 from "crypto-js/enc-base64";
import { environment } from "../../../environments/environment";
// import { LayoutService } from 'src/app/shared/services/layout.service';


@Injectable()
export class AuthenticationService {
    private authURL = environment.serverIP;
    private users = "api/users/"
    copyrightYear: BehaviorSubject<string> = new BehaviorSubject((new Date).getFullYear().toString());

    httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache, no-store, max-age=0, must-revalidate'
        })
    };
    constructor(private http: HttpClient) { }

    HMACGeneration(userKey, secretKey): Observable<any> {
        return new Observable(observer => {
            this.getPublicIPAddress().subscribe(data => {
                let response: any = data;
                if (response.status == "ok") {

                    let method = 'GET';
                    let timestamp = new Date().toISOString();
                    let additionPoint = "/api/users/";

                    let endPoint = `${method}\n${response.ip}\n${additionPoint}\n${timestamp}\n`;
                    let generatedHMAC = CryptoJS.algo.HMAC.create(
                        CryptoJS.algo.SHA256,
                        `${secretKey}`
                    );
                    generatedHMAC.update(endPoint);
                    let HMAC = Base64.stringify(generatedHMAC.finalize());
                    observer.next({
                        status: "ok",
                        h_macc: HMAC,
                        u_lkey: userKey,
                        timestamp: timestamp
                    });
                    observer.complete();
                }
                else {
                    observer.next({ status: "error" });
                    observer.complete();
                }
            }, err => {
                observer.next({ status: "error", err: err });
                observer.complete();
            });
        });
    }

    loginUser(credentials): Observable<any> {
        return new Observable(observer => {
            this.HMACGeneration(credentials.user_key, credentials.secret_key).subscribe(result => {
                if (result.status == "ok") {
                    // console.log(result);
                    observer.next({ status: "ok", token: '1234' });
                    observer.complete();
                    // this.http.post(this.authURL + 'api-token-auth/', { username: credentials.userName, password: credentials.password }, this.httpOptions).subscribe(data => {
                    //     let response: any = data;
                    //     console.log(response);
                    //     if (response && response.token) {
                    //         observer.next({ status: "ok", token: response.token });
                    //         observer.complete();
                    //     }
                    //     else {
                    //         observer.next({ status: "error" });
                    //         observer.complete();
                    //     }
                    // }, err => {
                    //     observer.next({ status: "error", err: err });
                    //     observer.complete();
                    // });
                }
                else {
                    return;
                }
            }, err => {
                observer.next({ status: "error", err: err });
                observer.complete();
            })
        });
    }


    getUserByEmail(params): Observable<any> {
        return new Observable(observer => {
            this.http.get(`${this.users}`, params).subscribe(data => {
                if (data) {
                    observer.next({ status: "ok", user: data });
                    observer.complete();
                }
            });
        });
    }

    getPublicIPAddress(): Observable<any> {
        return new Observable(observer => {
            this.http.get('https://api.ipify.org/?format=json').subscribe(data => {
                let response: any = data;
                if (response) {
                    observer.next({ status: "ok", ip: response.ip });
                    observer.complete();
                }
                else {
                    observer.next({ status: "error" });
                    observer.complete();
                }
            }, err => {
                observer.next({ status: "error" });
                observer.complete();
            });
        });
    }

    public getCopyrightYear(): Observable<string> {
        return this.copyrightYear.asObservable();
    }



    Logout() {
        localStorage.removeItem("currentUser");
        localStorage.removeItem("secretKey");
        localStorage.removeItem("userKey");
    }
}