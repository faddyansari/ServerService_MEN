import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { LoginComponent } from '../templates/login/login.component';
import { AuthenticationService } from '../services/authService';
import { AuthRoutes } from '../routes/authRoutes';
import { AuthGuard } from '../guards/authGuard';
import { JwtInterceptor } from '../interceptors/JWTInterceptor';
// import { MockBackend } from '@angular/http/testing';

// import { AuthRoutingModule } from './auth-routing.routing';
// import { AuthComponent } from './auth.component';
// import { LogoutComponent } from './logout/logout.component';
// import { AuthGuard } from './_guards/auth.guard';
// import { AuthenticationService } from './_services/authentication.service';
// import { JwtInterceptor } from './interceptors/jwt.interceptor';

// import { NgxUiLoaderModule } from  'ngx-ui-loader';
// import { HmacGenerationService, IPAddressService } from './_services';
// // import { fakeBackendProvider } from './_helpers/index';
// // import { WebConfig } from '../WebConfig';

// // particle.js
// import { ParticlesModule } from "angular-particle";

@NgModule({
    declarations: [
        LoginComponent
        // LogoutComponent
    ],
    imports: [
        CommonModule,
        FormsModule,
        HttpClientModule,
        AuthRoutes,
        FormsModule,
        ReactiveFormsModule
    ],
    providers: [
        AuthGuard,
        AuthenticationService,
        { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true }
        // IPAddressService,
        // HmacGenerationService,
        // { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true }
        // api backend simulation
        // fakeBackendProvider,
        // MockBackend,
        // BaseRequestOptions,
        // WebConfig,
    ],
    // entryComponents: [AlertComponent],
})

export class AuthModule {
}