// http://localhost:4200/#/
// URL can contain some data prepended with a # character.
// The # part of the URL is called the hash fragment.
// Another way to think about the hash fragment, since it's never sent to the server,
// is that it's for storing the state of your client application.

import { Component, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { LayoutService } from 'src/app/shared/services/layout.service';
import { AuthenticationService } from '../../services/authService';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class LoginComponent {
  hmacEnabled = true;
  loginForm: FormGroup;
  alertPopUp = false;
  errorText = '';
  whiteSpaceRegex = /^\S*$/;
  emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

  copyRightYear = '';
  subscriptions: Subscription[] = []
  constructor(private formBuilder: FormBuilder, private _authService: AuthenticationService,private _layoutService:LayoutService, private _router: Router) {

    

    this.loginForm = this.formBuilder.group({
      userName: ['', [Validators.required, Validators.pattern(this.whiteSpaceRegex)]],
      password: ['', [Validators.required]],
      secret_key: [''],
      user_key: ['']
    });

    this.subscriptions.push(this._authService.getCopyrightYear().subscribe(copyRightYear => {
      this.copyRightYear = copyRightYear;
    }));
    this.subscriptions.push(this._layoutService.HMACEnabled.subscribe(enabled => {
      this.hmacEnabled = enabled;
    }));
  }

  Login() {
    if (this.loginForm.valid) {
      this._authService.loginUser(this.loginForm.value).subscribe(result => {
        if (result.status == "ok") {
          localStorage.setItem("currentUser", JSON.stringify(result.token));
          localStorage.setItem("secretKey", JSON.stringify(this.loginForm.value.secret_key));
          localStorage.setItem("userKey", JSON.stringify(this.loginForm.value.user_key));

          // Navigate to Dashboard Component
          this._router.navigate(["pages"]);

          // No need right now
          // let params = {
          //   data: { userName: this.loginForm.value.userName },
          //   hmac_sig: result.h_macc,
          //   u_key: result.u_lkey,
          //   timestamp: result.timestamp
          // }
          // this._authService.getUserByEmail(params).subscribe(data => {
          //   if (data && data.username == this.loginForm.value.userName) {
          //   } else {
          //     this._router.navigate(["../logout"]);
          //   }
          // }, err => {
          //   this._router.navigate(["../logout"]);
          // });

        }
        else {
          return;
        }
      }, err => {
        this.HandleErrors(err);
        return;
      })
    }
  }

  ValidateKeys() {
    // && !this.whiteSpaceRegex.test(this.loginForm.get('secret_key').value) && !this.whiteSpaceRegex.test(this.loginForm.get('user_key').value)
    if (this.hmacEnabled && !(this.loginForm.get('secret_key').value && this.loginForm.get('user_key').value)) {
      return true;
    }
    else return false;
  }

  isAuth() {
    const user = localStorage.getItem('currentUser');
    return !!user;
  }


  HandleErrors(error?) {
    console.log(error);
    switch (error.status) {
      case 400 || 401:
        this.showAlert("Invalid Credentials");
        break;
      case 500:
        this.showAlert("Internal Server Error");
        break;
      case 0:
        this.showAlert("Service Temporarily Unavailable, please try again");
        if (this.isAuth()) {
          localStorage.removeItem("currentUser");
          this._router.navigate(["/login"]);
        }
        break;
      default:
        this.showAlert("Something went wrong, Please try again");
    }
  }

  showAlert(target) {
    this.alertPopUp = true;
    this.errorText = target;
  }

  ngOnDestroy() {
    this.subscriptions.forEach(subscription => {
      subscription.unsubscribe();
    })
  }

}
